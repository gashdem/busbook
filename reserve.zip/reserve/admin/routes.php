<?php
require_once("../databases.php");
require_once("../functions.php");
navigation($user_id);

try {
    $sql = "SELECT * FROM routes";
    $result = $conn->query($sql);
    $result->setFetchMode(PDO::FETCH_ASSOC);

    echo "<div class=\"col-md-3\">";
    echo "<div class=\"container\">";
     echo "<table class=\"table table-hover\">";

  
      echo "<thead>";
      echo "<tr>";
            echo "<th>Route Id</th>";
            echo "<th>Route Title</th>";
            echo "<th>From </th>";
            echo "<th>To</th>";
            echo "<th>Date </th>";
            echo " <th>Route Status</th>";
            echo " <th>Action</th>";
            echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        while($route = $result->fetch()):
        $route_id = test_input($route['route_id']);
        $route_title = test_input($route['route_title']);
        $route_from = test_input($route['route_from']);
        $route_to = test_input($route['route_to']);
        $route_date = date("j F Y g:i:s", strtotime($route['date']));
        $route_status = test_input($route['route_status']);

      echo "<tr>";
      echo "<td> $route_id  </td>";
      echo "<td> $route_title  </td>";
      echo "<td> $route_from  </td>";
      echo "<td> $route_to </td>";
      echo "<td> $route_date  </td>";
      if($route_status === "Activated") {
  
          echo "<td><a href='update_route_status.php?route_id=$route_id'>
              ".$route_status."
              </a></td>";
      } else {
            echo "<td><a href='update_route_status.php?route_id=$route_id'>
            ".$route_status."
            </a></td>";
      }

      echo "<td><a href='add_bus.php?id=$user_id&route_id=$route_id'>Add Bus</a> |
      <a href='delete.php?id=$user_id&route_id=$route_id'>Delete Route</a></td>";

            echo "</tr>";
        endwhile;
    echo "</tbody>";
    echo "</table>";

     echo "</div>";
    echo "</div>";
     echo "</div>";

}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
    $conn = null;
?>
