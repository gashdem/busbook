

<?php
require_once("../databases.php");
require_once("../functions.php");
navigation($user_id);

try {

    $sql = "SELECT * FROM users";
    // Prepare statement
    $stmt = $conn->prepare($sql);
    // execute the query
    $stmt->execute();
    // echo a message to say the UPDATE succeeded
   //$stmt->rowCount();
    
?>

<div class="col-md-3">;

<div class="container">
  <div class="jumbotron">
    <h1>Bootstrap Tutorial</h1>
    <p>Bootstrap is the most popular HTML, CSS, and JS framework for developing
    responsive, mobile-first projects on the web.</p>
  </div>

</div>


<div class="container">
  <div class="row">

    <center>
    <div class="col-md-2">
      <p> <button type="button" class="btn btn-success">Members <span class="badge"><?php echo $stmt->rowCount($sql);?></span></button></p>
    </div>


    <div class="col-md-2"> 
      <p> <button type="button" class="btn btn-info">Actived <span class="badge"></span></button></p>
    </div>


    <div class="col-md-2"> 
      <p> <button type="button" class="btn btn-warning">Deactivated <span class="badge"></span></button></p>
    </div>

    <div class="col-md-2"> 
      <p> <button type="button" class="btn btn-danger">Primary <span class="badge">7</span></button></p>
    </div>

    <div class="col-md-2"> 
      <p> <button type="button" class="btn btn-default">Primary <span class="badge">7</span></button></p>
    </div>

    <div class="col-md-2"> 
      <p> <button type="button" class="btn btn-primary">Primary <span class="badge">7</span></button></p>
    </div>
</center>

    <div class="clearfix visible-lg"></div>
  </div>
</div>




</div>

<?php 

}
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
?>
