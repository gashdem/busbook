<?php
error_reporting(0);
require_once("../databases.php");
require("../functions.php");

navigation($user_id);

$route_titleErr = $route_fromErr = $route_toErr = $route_statusErr = "";
$route_title = $route_from = $route_to = $route_status = "";


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    foreach( $stmt = $conn->query("SELECT route_title, route_from, route_to FROM routes") as $row) {
        $_SESSION["route_title"] = $row["route_title"];
        $_SESSION["route_from"] = $row["route_from"];
         $_SESSION["route_to"] = $row["route_to"];
     }
   
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;


if ($_SERVER["REQUEST_METHOD"] == "POST") { 
  
 if (empty($_POST["route_from"])) {
    $errors["route_fromErr"] = " * Required";
  } else {
    $route_from = test_input(ucname($_POST["route_from"]));   
    // check if name only contains letters and whitespace
     if (!preg_match("/^[\\\\a-zA-Z\']*$/",$route_from)) {
       $errors['route_titleErr'] = "Only letters and white space allowed";
     }
}  

 if (empty($_POST["route_to"])) {
     $errors["route_toErr"] = " * Required";
   } else {
     $route_to = test_input(ucname($_POST["route_to"]));
    // check if name only contains letters and whitespace
     if (!preg_match("/^[\\\\a-zA-Z\']*$/",$route_to)) {
       $errors['route_toErr'] = "Only letters and white space allowed";
     } elseif ($route_from === $route_to) {
       $errors['route_titleErr'] = "Destination and Origin can not be similar";
     } else {

        $route_title = $route_from."-".$route_to;
        if($_SESSION["route_title"] === $route_title){
            $errors['route_titleErr'] = "Route already exist";
        }
     }
   }

} 





if(empty($errors) && isset($_POST["submit"])) { 
    
    $route_status = "Activated";
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "INSERT INTO routes (route_title, route_from, route_to, route_status)
    VALUES ('$route_title','$route_from','$route_to', '$route_status')";
     // use exec() because no results are returned
    $conn->exec($sql);
    $msg = "Route Created Successfully<br>";
    //header('Refresh: 3; login.php');
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
    $conn = null;
}
?>

<html>
<body>
<div class=\"container">
<form method="post" class="form-horizontal" role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

<div class="col-md-6">
<?php
    $titleErr = $errors["route_titleErr"];
    if(isset($titleErr)) {
    echo 
    "
    <div>
        <code> $titleErr <br/> </code> 
    </div>
    ";
    }


    if(isset($msg)) {
    echo 
    "
    <div>
        <code> $msg <br/> </code> 
    </div>
    ";
    }
    ?>

            <div class="form-group">
                <label class="control-label col-sm-2" for="route_from">From:</label>
                <div class="col-sm-10">
                <input type="text" name="route_from" class="form-control" placeholder="Enter Origin" value="<?php echo stripslashes($route_from)?>">
                <br/>
                <code><?php echo $errors["route_fromErr"]; ?></code>
                </div>
            </div>

            <div class="form-group"> 
                <label class="control-label col-sm-2" for="route_to">To:</label>
                <div class="col-sm-10">
                <input type="text" name="route_to"  class="form-control" placeholder="Enter Destination" value="<?php  echo stripslashes($route_to)?>">
                <br/>
                <code><?php echo  $errors["route_toErr"]; ?></code>
                </div>
            </div>


            <div class="form-group">        
                <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default" name="submit" value="Submit">Submit</button>
                </div>
            </div>

</div>      
      
</form>
  </div>
</body>
</html> 

