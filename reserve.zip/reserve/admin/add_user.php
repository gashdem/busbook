<?php
ob_start();
error_reporting(0);
require_once("../databases.php");
require("../functions.php");

navigation($user_id);

$fnameErr = $lnameErr = $genderErr = $emailErr = $usernameErr = $passwordErr = $password1Err = $user_typeErr = "";
$fname = $lname = $gender = $email = $username = $password = $password1 = $user_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") { 

  try {

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    foreach( $stmt = $conn->query("SELECT username, email FROM users") as $row) {
        $_SESSION["email"] = $row["email"];
        $_SESSION["username"] = $row["username"];
     }

  }

  catch(PDOException $e) {

    echo "Error: " . $e->getMessage();
  }

  $conn = null;


  if (empty($_POST["fname"])) {
    $error["fnameErr"] = "First Name Is Required";
  } else {
    $fname = test_input(ucname($_POST["fname"]));
      // check if name only contains letters and whitespace
    if (!preg_match("/^[\\\\a-zA-Z\']*$/",$fname)) {
       $error["fnameErr"] = "Only letters and white spaces allowed";
    }
  }


  if (empty($_POST["lname"])) {
    $error["lnameErr"] = "Last Name Is Required";
  } else {
    $lname = test_input(ucname($_POST["lname"]));   
    // check if name only contains letters and whitespace
    if (!preg_match("/^[\\\\a-zA-Z\']*$/",$error["lnameErr"])) {
       $error["lnameErr"] = "Only letters and white spaces allowed";
    }
  }  

  if (empty($_POST["gender"])) {
    $error["genderErr"] = "Gender Is Required";
  } else {
    $gender = test_input(ucname($_POST["gender"]));   
    // check if name only contains letters and whitespace
     if (!preg_match("/^[\\\\a-zA-Z\']*$/",$gender)) {
       $error["genderErr"] = "Only letters and white spaces allowed";
     }
  } 

  if (empty($_POST["email"])) {
     $error["emailErr"] = "Email Is Required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $error["emailErr"] = "Invalid E-mail Format";
    } elseif ($_SESSION['email'] === $email) {
        $error["emailErr"] = "E-mail Already Exists";
    }
  }

  if (empty($_POST["username"])) {
    $error["usernameErr"] = "Username Is Required";
  } else {
    $username = test_input($_POST["username"]);
     if (!preg_match("/^[\\\\a-zA-Z\']*$/",$username)) {
       $error["usernameErr"] = "Only letters and white spaces allowed";
     }
    if ($_SESSION["username"] === $username) {
         $$error["usernameErr"] = "Username Already Exists";
     }
  }

  if (empty($_POST["password"])) {
    $error["passwordErr"] = "Password Is Required";  
  } else {
    $password = test_input($_POST["password"]);
  }

  if (empty($_POST["password1"])) {
    $error["password1Err"] = "Re-Enter Password";  
  } else {
    $password1 = test_input($_POST["password1"]);
      if ($password !== $password1) {
        $$error["password1Err"] = "Passwords Do Not Match";
      } 
  }
  

  if (empty($_POST["user_type"])) {
    $error["user_typeErr"] = "Role Is Required";
  } else {
    $user_type = test_input(ucname($_POST["user_type"]));   
    // check if name only contains letters and whitespace
     if (!preg_match("/^[\\\\a-zA-Z\']*$/",$user_type)) {
       $error["user_typeErr"] = "Only letters and white spaces allowed";
     }
  }  

} 

?>


<div class="container">
<?php 
//$msg = $_SESSION["msg"];
//if(isset($msg)) {
    //echo 
    //"
    //<div>
        //<center><code> $msg <br/> </code> </center>
    //</div>
    //";
//}

?>

<form method="post" class="form-horizontal" role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
<div class="col-md-6">

  <div class="form-group">
    <label class="control-label col-sm-4">First Name:</label>
    <div class="col-sm-8">
    <input type="text" name="fname" class="form-control" placeholder="Enter First Name" value="<?php echo $fname; ?>">
    <code><?php echo $error["fnameErr"]; ?></code>
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-sm-4">Last Name:</label>
    <div class="col-sm-8">
    <input type="text" name="lname" class="form-control" placeholder="Enter Last Name" value="<?php echo $lname; ?>">
    <code><?php echo $error["lnameErr"]; ?></code>
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-sm-4" >Gender:</label> 
    <div class="col-sm-8">
    <label class="radio-inline">
    <input type="radio" name="gender" <?php if (isset($gender) && $gender=="Female")
      echo "checked";?> value="Female">Female 
    </label>

    <label class="radio-inline">
    <input type="radio" name="gender" <?php if (isset($gender) && $gender=="Male")
      echo "checked";?> value="Male">Male 
    </label>
    <br/>
    <code><?php echo $error["genderErr"];?></code>
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-sm-4">E-mail:</label>
    <div class="col-sm-8">
    <input type="text" name="email" class="form-control" placeholder="Enter E-mail" value="<?php echo $email; ?>">    
    <code><?php echo $error["emailErr"]; ?></code>
    </div>
  </div>

  <div class="form-group">
      <label class="control-label col-sm-4">Username:</label>
      <div class="col-sm-8">
      <input type="text" name="username" class="form-control" placeholder="Enter Username" value="<?php echo $username; ?>">
     
      <code><?php echo $error["usernameErr"]; ?></code>
      </div>
  </div>

<div class="form-group">
      <label class="control-label col-sm-4">Password:</label>
      <div class="col-sm-8">
      <input type="password" name="password" class="form-control" placeholder="Enter Password" value="">
     
      <code><?php echo $error["passwordErr"]; ?></code>
      </div>
</div>

<div class="form-group">
      <label class="control-label col-sm-4">Re-Enter Password:</label>
      <div class="col-sm-8">
      <input type="password" name="password1" class="form-control" placeholder="Re-Enter Password" value="">
    
      <code><?php echo $error["password1Err"]; ?></code>
      </div>
</div>

<div class="form-group">
      <label class="control-label col-sm-4" >Role:</label> 
      <div class="col-sm-8">
        <label class="radio-inline">
        <input type="radio" name="user_type" <?php if (isset($user_type) && $user_type=="Admin")
        echo "checked";?> value="Admin">Admin 
        </label>

        <label class="radio-inline">
        <input type="radio" name="user_type" <?php if (isset($user_type) && $user_type=="Manager")
        echo "checked";?> value="Manager">Manager 
         </label>

         <label class="radio-inline">
        <input type="radio" name="user_type" <?php if (isset($user_type) && $user_type=="Driver")
        echo "checked";?> value="Driver">Driver
        </label>
       <br/>
      <code><?php echo $error["user_typeErr"]; ?></code>
    </div>
</div>


   
    

	   <div class="form-group">        
          <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn btn-default" name="submit" value="Submit">Submit</button>
          </div>
      </div>
</div>
</form>
</div>
</body>
</html> 

<?php 

if(isset($_POST["submit"])) {
  if(empty($error)) {
    $user_status = "Activated";
    $hashed_password = hash_password($_POST['password']);
try {

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "INSERT INTO users (fname, lname, gender, email, username, hashed_password, user_type, user_status)
    VALUES ('$fname','$lname','$gender', '$email','$username','$hashed_password', '$user_type', '$user_status')";
     // use exec() because no results are returned
    $conn->exec($sql);
    //$_SESSION["msg"] = "Account Created Successfully<br>";
    header('Refresh: 3; users.php');
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
    $conn = null;
}
}
ob_flush();
?>