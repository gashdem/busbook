<?php

require_once("../functions.php");
require_once("../databases.php");
$route_id = $_GET["route_id"];
$user_id = $_SESSION["user_id"];

try {
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT route_status FROM routes WHERE route_id = '$route_id'";
	$result = $conn->query($sql);
	$result->setFetchMode(PDO::FETCH_ASSOC);

	while ($route_set = $result->fetch()):
		echo $current_status = $route_set['route_status'];
	endwhile;
}
catch(PDOException $e) {
	echo "Error: " . $e->getMessage();
}

if($current_status === "Activated"){
	$sql = "UPDATE routes SET route_status = ? WHERE route_id = ?";
	$new_status = "Deactivated";
	$stmt = $conn->prepare($sql);
	$stmt->execute(array($new_status, $route_id));
	redirect("routes.php?id=$user_id");
} else {
	$sql = "UPDATE routes SET route_status = ? WHERE route_id = ?";
	$new_status = "Activated";
	$stmt = $conn->prepare($sql);
	$stmt->execute(array($new_status, $route_id));
	redirect("routes.php?id=$user_id");
}

?>