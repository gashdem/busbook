<?php
require_once("../databases.php");
require_once("../functions.php");
navigation($user_id);
if(!isset($route_id)){
    $route_id = $_GET["route_id"] - $_SESSION["route_id"];
    }
$bus_titleErr = $bus_seatsErr = "";
$bus_title = $bus_seats = "";


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    foreach( $stmt = $conn->query("SELECT bus_title, bus_seats FROM buses") as $row) {
        $_SESSION["bus_title"] = $row["route_title"];
        $_SESSION["bus_seats"] = $row["bus_seats"];
         $_SESSION["bus_id"] = $row["bus_id"];
     }
   
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;


if ($_SERVER["REQUEST_METHOD"] == "POST") { 
  
 if (empty($_POST["bus_title"])) {
    $errors["bus_titleErr"] = " * Required";
  } else {
    $bus_title = test_input(ucname($_POST["bus_title"]));   
    // check if name only contains letters and whitespace
     if (!preg_match("/^[\\\\a-zA-Z\']*$/",$bus_title)) {
       $errors['route_titleErr'] = "Only letters and white space allowed";
     }
}  

if (empty($_POST["bus_seats"])) {
    $errors["bus_seatsErr"] = " * Required";
  } else {
    $bus_title = test_input(ucname($_POST["seats_title"]));   
    // check if name only contains letters and whitespace
     if (!preg_match("/^[\\\\a-zA-Z\']*$/",$bus_seats)) {
       $errors['route_titleErr'] = "Only letters and white space allowed";
     }
}  

 
   }

?>

<form method="post" class="form-horizontal" role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<div class="col-md-6">
<div class="form-group">
      <label class="control-label col-sm-4" for="bus_title">Bus Title:</label>
      <div class="col-sm-8">
      <input type="text" name="bus_title" class="form-control" placeholder="Enter Bus No. Plate" value="<?php echo stripslashes($bus_title)?>">
      <code><?php echo $errors["bus_titleErr"]; ?></code>
      </div>
</div>

 <div class="form-group">
  <label class="control-label col-sm-4" for="sel1">No. of Seats:</label>
  <div class="col-sm-8">
  <select class="form-control" id="sel1" name="bus_seats">
    <option value=""> -- choose -- </option>
    <option value="10">10</option>
    <option value="50">50</option>
    <option value="62">62</option>
  </select>
  <code><?php echo $errors["bus_seatsErr"]; ?></code>
  </div>
</div>


       <div class="form-group">        
                <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default" name="submit" value="Submit">Submit</button>
                </div>
            </div>
</div>
</form>
</div>
</body>
</html> 

<?php 
 if(empty($errors) && isset($_POST["submit"])) { 
    
    $bus_status = "Activated";
try {

    $sql = "INSERT INTO busess (route_id, bus_title, bus_seats, bus_status)
                        VALUES ('$route_id','$bus_title','$bus_seats', '$bus_status')";
     // use exec() because no results are returned
    $conn->exec($sql);
    $msg = "Bus Added Successfully<br>";
    //header('Refresh: 3; login.php');
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
    $conn = null;
}


$bus_title = $_POST["bus_title"];
$bus_seats = $_POST["bus_seats"];
echo $bus_title . "</br>";
echo $bus_seats . "</br>";
echo $route_id . "</br>";
?>

