
<?php
require("../functions.php");
require_once("../databases.php");
navigation($user_id);

$genderErr = $fnameErr = $lnameErr = $usernameErr = $emailErr = "";
$user_type = $gender = $fname = $lname = $username = $email = "";

try {
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	foreach ($stmt = $conn->query("SELECT * FROM users WHERE user_id = '$user_id'") as $row) {

	}
}
catch(PDOException $e)
{
		echo "Error: " . $e->getMessage();
}

?>

<html>
<body>

<div class=\"container">

<form method="post" class="form-horizontal" role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<div class="col-md-6">

<div class="form-group">
      <label class="control-label col-sm-4">First Name:</label>
      <div class="col-sm-8">
      <input type="text" name="fname" class="form-control" value="<?php echo stripslashes($row["fname"])?>">
      <br/>
      <code><?php echo $errors["fnameErr"]; ?></code>
      </div>
</div>

	<div class="form-group">
      <label class="control-label col-sm-4">Last Name:</label>
      <div class="col-sm-8">
      <input type="text" name="lname" class="form-control"  value="<?php echo stripslashes($row['lname'])?>">
      <br/>
      <code><?php echo $errors["lnameErr"]; ?></code>
      </div>
</div>

<div class="form-group">
      <label class="control-label col-sm-4" >Gender:</label> 
      <div class="col-sm-8">
    <label class="radio-inline">
      <input type="radio" name="gender" <?php if ($row["gender"] == "Female")
      echo "checked";?> value="Female">Female 
    </label>

    <label class="radio-inline">
      <input type="radio" name="gender" <?php if ($row["gender"] == "Male")
      echo "checked";?> value="Male">Male 
    </label>
    <br/>
      <code><?php echo $errors["genderErr"]; ?></code>
    </div>
</div>


<div class="form-group">
      <label class="control-label col-sm-4">E-mail:</label>
      <div class="col-sm-8">
      <input type="text" name="email" class="form-control"  value="<?php echo $row['email']?>">
      <br/>
      <code><?php echo $errors["emailErr"]; ?></code>
      </div>
</div>
<div class="form-group">
      <label class="control-label col-sm-4">Username:</label>
      <div class="col-sm-8">
      <input type="text" name="username" class="form-control"  value="<?php echo $row['username']?>">
      <br/>
      <code><?php echo $errors["usernameErr"]; ?></code>
      </div>
</div>
	  
	  <div class="form-group">        
                <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default" name="submit" value="submit">Submit</button>
                </div>
            </div>
</div>
</form>
</div>
</body>
<?php

$fname = $_POST["fname"];
$lname = $_POST["lname"];
$gender = $_POST["gender"];
$email = $_POST["email"];
$username = $_POST["username"];

if(empty($errors) &&  isset($_POST["submit"])) {

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "UPDATE users SET fname='$fname', lname='$lname', gender='$gender', email='$email',
    username='$username'  WHERE user_id='$user_id'";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    // execute the query
    $stmt->execute();

    // echo a message to say the UPDATE succeeded
   
    //echo $stmt->rowCount() . " records UPDATED";

    
          header("Location: users.php?id=$user_id");

    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
}

$conn = null;
?>
