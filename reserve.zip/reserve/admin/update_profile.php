<?php
require_once("../databases.php");
require("../functions.php");

$user_id;

$fname = $_POST["fname"];
$lname = $_POST["lname"];
$gender = $_POST["gender"];
$email = $_POST["email"];
$username = $_POST["username"];

echo $fname . "<br/>";
echo $lname . "<br/>";
echo $gender . "<br/>";
echo $email . "<br/>";
echo $username . "<br/>";

if(empty($errors) &&  isset($_POST["submit"])) {

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "UPDATE users SET fname='$fname', lname='$lname', gender='$gender', email='$email',
    username='$username'  WHERE user_id='$user_id'";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    // execute the query
    $stmt->execute();

    // echo a message to say the UPDATE succeeded
    $_SESSION["msg"] = $stmt->rowCount() . " records UPDATED successfully";
    header("profile.php?id=$user_id");
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
}

$conn = null;

?>