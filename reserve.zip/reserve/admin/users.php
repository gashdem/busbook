<?php
require_once("../databases.php");
require_once("../functions.php");
navigation($user_id);

try{

  $sql = "SELECT * FROM users";
  $result = $conn->query($sql);
  $result->setFetchMode(PDO::FETCH_ASSOC);

  echo "<div class=\"col-md-3\">";
    echo "<div class=\"container\">";
      echo "<table class=\"table table-hover\">";
        echo "<thead>";
          echo "<tr>";
            echo "<th>ID</th>";
            echo "<th>Names</th>";
            echo "<th>Gender</th>";
            echo "<th>E-mail</th>";
            echo "<th>Role</th>";
            echo "<th>Joined</th>";
            echo "<th>Status</th>";
          echo "</tr>";
        echo "</thead>"; 
        
        echo "<tbody>"; 
        while($user = $result->fetch()):
          $user_user_id = test_input($user['user_id']);
          $user_fname = test_input($user['fname']);
          $user_lname = test_input($user['lname']);
          $user_gender = test_input($user['gender']);
          $user_email = test_input($user['email']);
          $user_user_type = test_input($user['user_type']);
          $user_reg_date = date("j F Y g:i:s", strtotime($user['reg_date']));
          $user_user_status = test_input($user['user_status']);

            echo "<tr>";
            echo "<td> $user_user_id </td>";
            echo "<td> $user_fname&nbsp;$user_lname  </td>";
            echo "<td> $user_gender </td>";
            echo "<td> $user_email  </td>";
            echo "<td> $user_user_type  </td>";
            echo "<td> $user_reg_date  </td>";

          if($user_user_status === "Activated") {
               echo "<td><a href='update_user_status.php?user_user_id=$user_user_id'>".$user_user_status."</a></td>";
          } else {
               echo "<td><a href='update_user_status.php?user_user_id=$user_user_id'>".$user_user_status."</a></td>";
          }  
            echo "</tr>";

        endwhile;

        echo "</tbody>";
  echo "</table>";
      echo "</div>";
    echo "</div>";
  echo "</div>";
}

catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
    $conn = null;
?>


