<?php
error_reporting(0);
require("../functions.php");
require_once("../databases.php");
navigation($user_id);
$passwordErr = $password1Err = $password2Err = "";
$password = $password1 = $password2 = "";

try {
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	foreach( $stmt = $conn->query("SELECT hashed_password FROM users WHERE username = '$_SESSION[name]'") as $row) {
		$old_password = $row["hashed_password"];
	}
}
catch(PDOException $e) {
	echo "Error: " . $e->getMessage();
}
$conn = null;


if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["password"])) {
		$errors["passwordErr"] = "Old Password Is Required";
	} else {
		$password = test_input($_POST["password"]);

		if(!password_verify($password, $old_password)){
			$errors["passwordErr"] = "Password Does Not Match Records";
		}
	}

	if (empty($_POST["password1"])) {
		$errors["password1Err"] = "New Password Is Required";
	} else {
		$password1 = test_input($_POST["password1"]);
	}

	if (empty($_POST["password2"])) {
		$errors["password2Err"] = "Re-Enter New Password";
	} else {
		$password2 = test_input($_POST["password2"]);
		if($password1 !== $password2){
			$errors["password2Err"] = "Does Not Match New Password";
		}

	}
if(empty($errors) && isset($_POST["submit"])) {
	$new_password = hash_password($password2);
	try {
		$conn = new PDO("mysql:host=$servername;dbname=$dbname", $user, $pass);
		// set the PDO error mode to exception
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE users SET hashed_password = '$new_password' WHERE username = '$_SESSION[name]'";
		// Prepare statement
		$stmt = $conn->prepare($sql);
		// execute the query
		$stmt->execute();

		// echo a message to say the UPDATE succeeded
		echo $stmt->rowCount() . " Account UPDATED Successfully";
		header("Refresh: 5; change_password.php?id=$user_id");
	} catch (PDOException $e) {
		echo $sql . "<br>" . $e->getMessage();
	}
	$conn = null;
}
	echo "<br>";
}
?>

<html>
<body>
<div class=\"container">
<form method="post" class="form-horizontal" role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<div class="col-md-6">
<div class="form-group">
      <label class="control-label col-sm-4">Old Password:</label>
      <div class="col-sm-8">
      <input type="password" name="password" class="form-control" placeholder="Enter Old Password" value="">
     
      <code><?php echo $errors["passwordErr"]; ?></code>
      </div>
</div>	

<div class="form-group">
      <label class="control-label col-sm-4">New Password:</label>
      <div class="col-sm-8">
      <input type="password" name="password1" class="form-control" placeholder="Enter New Password" value="">
     
      <code><?php echo $errors["password1Err"]; ?></code>
      </div>
</div>	

<div class="form-group">
      <label class="control-label col-sm-4">Re-Enter New Password:</label>
      <div class="col-sm-8">
      <input type="password" name="password2" class="form-control" placeholder="Re-Enter New Password" value="">
     
      <code><?php echo $errors["password2Err"]; ?></code>
      </div>
</div>	

 <div class="form-group">        
                <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default" name="submit" value="Submit">Submit</button>
                </div>
            </div>
&nbsp;
             <div class="form-group">        
                <div class="col-sm-offset-2 col-sm-10">
                <button type="reset" class="btn btn-default" name="reset" value="reset">Reset</button>
                </div>
            </div>

</div>
</form>
</div>
</body>
</html> 