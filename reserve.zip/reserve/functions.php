<?php
ob_start();
require_once("sessions.php");
error_reporting(0);
require_once("databases.php");
/* --------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------- */
function redirect($url){
	header("Location: $url");
}
/* --------------------------------------------------------------------------------- */
function hash_password($password){
	$cost = 10;
	$salt = strtr(base64_encode(mcrypt_create_iv(16, MCRYPT_DEV_URANDOM)), '+', '.');
	$salt = sprintf("$2a$%02d$", $cost) . $salt;
	$hash = crypt($password, $salt);
	return $hash;
}
/* --------------------------------------------------------------------------------- */

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = addslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
/* --------------------------------------------------------------------------------- */

function ucname($string) {
    $string =ucwords(strtolower($string));

    foreach (array('-', '\'') as $delimiter) {
      if (strpos($string, $delimiter)!==false) {
        $string =implode($delimiter, array_map('ucfirst', explode($delimiter, $string)));
      }
    }
    return $string;
}
/* --------------------------------------------------------------------------------- */

function find_user($username, $email){
	global $conn;	
	try {

		$stmt = $conn->prepare("SELECT * FROM users WHERE username=:username OR email=:email LIMIT 1");
		$stmt->bindParam(':username', $username);
		$stmt->bindParam(':email', $email);
		$stmt->execute();

		if( $user_set = $stmt->fetch(PDO::FETCH_ASSOC)) {
		
			return $user_set;
		} else {
			$_SESSION["error_msg"] = "Username, Password OR Email Not Found <br>";
			return null;
		}

	}
	catch(PDOException $e){
		echo "Error: " . $e->getMessage();
	}
	$conn = null;
}

/* --------------------------------------------------------------------------------- */
function attempt_login($username, $password, $email) {
		$user_set = find_user($username, $email);
		
		if(password_verify($password, $user_set["hashed_password"])) {
			$_SESSION["user_id"] = $user_set["user_id"];
			$_SESSION["name"] = $user_set["username"];
			$_SESSION["mail"] = $user_set["email"];
			$_SESSION["user_type"] = $user_set["user_type"];
			$_SESSION["user_status"] = $user_set["user_status"];

			return $user_set;

		} else {

			$_SESSION["error_msg"] = "Username, Password OR Email Not Found <br>";

			return false;

		}	

}
/* --------------------------------------------------------------------------------- */

$user_id = $_SESSION["user_id"];
/* --------------------------------------------------------------------------------- */


function bootstrap_head($user_id){
  echo 
  '
    <!DOCTYPE html>
      <html lang="en">
		<head>
  			<title>E-Bus</title>
  			<meta charset="utf-8">
  			<meta name="viewport" content="width=device-width, initial-scale=1">
  			<link rel="stylesheet" href="../bootstrap-3.3.6-dist/css/bootstrap.min.css">
  			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  			<script src="http:../bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
		</head>
  ';
  return $user_id;
}
/* --------------------------------------------------------------------------------- */



/* --------------------------------------------------------------------------------- */


function navigation($user_id){
	global $user_id;
	if(!isset($user_id) && $user_id == ""){
		echo "Sorry, Please <a href=\"../login.php\">login</a>";
		exit;
	}else {

		if ($_POST["username"] == "admin" && $_POST["password"] == password_verify($password, $user_set["hashed_password"])) {
		    $_SESSION["authorized"] = true;
		    session_regenerate_id();
		}

		bootstrap_head(); 

		$role = $_SESSION["user_type"];
		$name = $_SESSION["name"];
		$email = $_SESSION["mail"];
		
		echo 
		"
	<nav class=\"navbar navbar-default\">

  		<div class=\"container-fluid\">

    		<div class=\"navbar-header\">

		      <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
		        <span class=\"icon-bar\"></span>
		        <span class=\"icon-bar\"></span>
		        <span class=\"icon-bar\"></span>                        
		      </button>

      		  <a class=\"navbar-brand\" href=\"admin.php\">E-Bus</a>
    		</div>


    		<div class=\"collapse navbar-collapse\" id=\"myNavbar\">

		      <ul class=\"nav navbar-nav\">
		        <li class=\"active\"><a href=\"index.php\">Home</a></li>

		        
        
       
      </ul>

 
      <ul class=\"nav navbar-nav navbar-right\">
        <li class=\"dropdown\">
          <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"profile.php?id=$user_id\">Logged In, $role:$name <span class=\"caret\"></span></a>

          <ul class=\"dropdown-menu\">
            <li><a href=\"profile.php?id=$user_id\">Edit Profile</a></li>
            <li><a href=\"change_password.php?id-$user_id\">Reset Password</a></li>
            <li><a href=\"../logout.php\">Logout</a></li>
          </ul>
        </li>

    </div>
  </div>
</nav>
		";

			if($_SESSION["user_type"] === "Admin"){

  			echo 
  			"
					 
					  <div class=\"col-md-2\">
					
					  <ul class=\"nav nav-pills nav-stacked\">
					    <li class=\"active\"><a href=\"admin.php?id=$user_id\">Dashboard</a></li>

					    <li class=\"dropdown\">
					      <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"bus.php?id=$user_id\">Buses <span class=\"caret\"></span></a>
					      <ul class=\"dropdown-menu\">
					        <li><a href=\"bus.php?id=$user_id\">Buses</a></li>
					                
					      </ul>
					    </li>

					    <li class=\"dropdown\">
					      <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"routes.php?id=$user_id\">Routes <span class=\"caret\"></span></a>
					      <ul class=\"dropdown-menu\">
					        <li><a href=\"routes.php?id=$user_id\">Routes</a></li>
					        <li><a href=\"add_route.php?id=$user_id\">Add Route</a></li>                      
					      </ul>
					    </li>


					   <li class=\"dropdown\">
					      <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"users.php?id=$user_id\"> Users <span class=\"caret\"></span></a>
					      <ul class=\"dropdown-menu\">
					        <li><a href=\"users.php?id=$user_id\">All Users</a></li>
					        <li><a href=\"add_user.php?id=$user_id\">Add User </a></li>
					        <li><a href=\"profile.php?id=$user_id\"> Your Profile </a></li>                        
					      </ul>
					    </li>

				
					  </ul>
					  </div>
					

  			";

  			if($_SESSION["user_type"] === "Manager"){
			echo "<a href=manager.php?id=$user_id>Home</a><br>";
		}

		if($_SESSION["user_type"] === "Driver"){
			echo "<a href=driver.php?id=$user_id>Home</a><br>";
		}

		}
	}
	return true;
}
/* --------------------------------------------------------------------------------- */


?>