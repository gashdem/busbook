<?php
ob_start();
error_reporting(0);
require("functions.php");
require_once("databases.php");
$username_emailErr = $passwordErr = "";
$username_email = $password = $email = $username = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["username_email"])) {
    $errors["username_emailErr"] = "Username OR E-mail is Required";
  } else {
    $username_email = test_input($_POST["username_email"]);
  }

  if (empty($_POST["password"])) {
    $errors["passwordErr"] = "Password is Required";
  } else {
    $password = test_input($_POST["password"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$password)) {
      $passwordErr = "Only letters and white space allowed";
    }
  }

} 

if( isset($_POST["submit"])) {

    if(empty($errors)){

    	$username = $_POST['username_email'];
    	$email = $_POST['username_email'];
    	$password = $_POST['password'];

    	$found_user = attempt_login($username, $password, $email);

    	   if($found_user) {

            $user_id = $_SESSION['user_id'];

    		    if($_SESSION["user_type"] === "Admin" && $_SESSION["user_status"] === "Activated"){
                redirect("admin/admin.php?id=$user_id");
            } else {
                $error_msg = "Sorry&nbsp;" . ucname($username) .", your account is temporarily deactivated.<br>";
            }

            if($_SESSION["user_type"] === "Manager" && $_SESSION["user_status"] === "Activated") {
                redirect("manager.php?id=$user_id");
            } else {
                $error_msg = "Sorry&nbsp;" . ucname($username) .", your account is temporarily deactivated.<br>";
            }

            if($_SESSION["user_type"] === "Driver" && $_SESSION["user_status"] === "Activated") {
                redirect("driver.php?id=$user_id");
            } else {
                $error_msg = "Sorry&nbsp;" . ucname($username) .", your account is temporarily deactivated.<br>";
            }

    	   } else {

            if(!$found_user){
                $error_msg = $_SESSION["error_msg"];
            }
          }

      }
}
?>
<!DOCTYPE html>
<html>
	
<head>
	<title>The Login-Animated Website Template | Home :: w3layouts</title>
		<meta charset="utf-8">
		<link href="bootstrap-3.3.6-dist/css/style.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		<!--webfonts-->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,300,600,700' rel='stylesheet' type='text/css'>
		<!--//webfonts-->
    <style type="text/css">.error { color:#FF0000; }</style>
</head>
<body>
	
				 <!---start-main-->
				<div class="login-form">
					<div class="head">


						<img src="../bootstrap-3.3.6-dist/images/mem2.jpg" alt="" width="150" height="150"/>
					</div>
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
				<?php 
if(isset($error_msg)){ echo "<pre><span class='error'>".$error_msg."</span></pre>"; } 



?>
      <?php echo "<pre><span class='error'>" . $errors["username_emailErr"] . "</span></pre>";  ?>
					<li>
						<input type="text" class="text" placeholder="Username/E-mail" name="username_email" value="<?php echo $username_email;?>" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" ><a href="login.php" class=" icon user"></a>
      
					</li>

					<?php echo "<pre><span class='error'>" . $errors["passwordErr"] . "</span></pre>"; ?>
					<li>
						<input type="password" name="password" placeholder="Password" value="<?php echo $password;?>" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}"><a href="lohin.php" class=" icon lock"></a>
  	
					</li>
					
					<div class="p-container">
						   
							 <input type="submit" name="submit" value="Submit">
							<div class="clear"> </div>
					</div>
				</form>
			</div>
			<!--//End-login-form-->
		  <!---start-copyright-->
   					<div class="copy-right">
						<p><?php echo date(" F Y");?>
             <a href="http://instagram.com/macxwhale">code-igniters</a></p> 
					</div>
				<!---//end-copyright-->
		 		
</body>
</html>

