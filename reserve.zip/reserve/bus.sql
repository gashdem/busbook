-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2016 at 10:06 AM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bus`
--

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `bus_id` int(16) NOT NULL,
  `route_id` int(16) NOT NULL,
  `bus_title` varchar(255) NOT NULL,
  `bus_seats` int(16) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`bus_id`, `route_id`, `bus_title`, `bus_seats`, `date`, `time`) VALUES
(1, 1, 'KAV-6678', 10, '2016-03-27 16:40:20', '2016-02-28 11:23:19'),
(2, 2, 'KAV-9990', 10, '2016-03-27 16:41:44', '2016-03-29 13:17:55'),
(3, 3, 'KAV-9990', 10, '2016-03-27 16:41:44', '2016-03-30 10:23:44');

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `route_id` int(16) NOT NULL,
  `route_title` varchar(120) NOT NULL,
  `route_from` varchar(120) NOT NULL,
  `route_to` varchar(120) NOT NULL,
  `route_status` char(120) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`route_id`, `route_title`, `route_from`, `route_to`, `route_status`, `date`) VALUES
(23, 'Nakuru-Naivasha', 'Nakuru', 'Naivasha', 'Activated', '2016-03-27 18:41:11'),
(24, 'Nakuru-Nairobi', 'Nakuru', 'Nairobi', 'Activated', '2016-03-26 12:44:15'),
(25, 'Nakuru-Naivasha', 'Nakuru', 'Naivasha', 'Activated', '2016-03-27 13:25:23'),
(26, 'Nakuru-Kampala', 'Nakuru', 'Kampala', 'Activated', '2016-03-26 13:20:12'),
(27, 'Kampala-Nakuru', 'Kampala', 'Nakuru', 'Activated', '2016-03-26 13:48:55'),
(28, 'Nairobi-Kampala', 'Nairobi', 'Kampala', 'Activated', '2016-03-27 15:35:17'),
(29, 'Naivasha&nbsp;-&nbsp;Nairobi', 'Naivasha', 'Nairobi', 'Activated', '2016-03-27 18:04:23'),
(30, 'Garissa-Mombasa', 'Garissa', 'Mombasa', 'Activated', '2016-03-27 18:23:21'),
(31, 'Nakuru-Dadaab', 'Nakuru', 'Dadaab', 'Activated', '2016-03-27 18:25:13'),
(32, 'Nakuru-Malindi', 'Nakuru', 'Malindi', 'Activated', '2016-03-27 18:42:14'),
(33, 'Kisumu&nbsp;-&nbsp;Mombasa', 'Kisumu', 'Mombasa', 'Activated', '2016-03-27 18:43:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(6) UNSIGNED NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `hashed_password` varchar(200) NOT NULL,
  `user_type` varchar(30) NOT NULL,
  `user_status` varchar(30) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `lname`, `gender`, `email`, `username`, `hashed_password`, `user_type`, `user_status`, `reg_date`) VALUES
(1, 'Admin', 'Admin', 'Male', 'maxwellambenge@gmail.com', 'admin', '$2a$10$k3ylAQk24ErKyVptTgW35.o//1SXIjDfDk1l1.HWEHmEIGsww3Qqm', 'Admin', 'Activated', '2016-03-20 18:29:08'),
(2, 'Driver', 'Driver', 'Male', 'driver@driver.com', 'driver', '$2a$10$Dg1vpvpHowZUofPT6DQwpe3EtDA8o/rMrmRQLYWraZUaSKpX/CFfe', 'Driver', 'Activated', '2016-03-22 19:33:53'),
(3, 'Manager', 'Manager', 'Female', 'manager@manager.com', 'manager', '$2a$10$cOl3YiV9UObJ8PmFbChSfun/T/Y/CkS8L01lgZlQjiQ2W/XnEBiq.', 'Manager', 'Activated', '2016-03-22 19:34:52'),
(4, 'Maxwell', 'Ambenge', 'Male', 'macxwhale@gmail.com', 'macx', '$2a$10$uEdTIDxsk8l.uZVYgyOWxOREt1lAeK4hUkdRHxxTXrxMh8LlOzFdW', 'Admin', 'Activated', '2016-03-26 14:43:42'),
(5, 'Peter', 'Ambenge', 'Female', 'peter@gmail.com', 'peter', '$2a$10$k49D93Vu1NsIiryrLGX53OsESAKD8vajCWuHiczhFnOvvo7AGndtO', 'Manager', 'Activated', '2016-03-26 15:24:42'),
(6, 'Peter', 'Ambenge', 'Female', 'ambenge@gmail.com', 'ambenge', '$2a$10$0rXfzEf1iDHvZ4ZApKVxZeVBwedzoGtGDWF12tHQmyvknkO0nYeGG', 'Driver', 'Activated', '2016-03-26 15:27:49'),
(7, 'Peter', 'Ambenge', 'Female', 'max@gmail.com', 'ambengee', '$2a$10$yy3CnK1bFKAQz1U0RbaoxODdIF922/erBWv3t2PwFX3EKNEUTnp1e', 'Admin', 'Deactivated', '2016-03-26 15:29:46'),
(8, 'John', 'Doe', 'Male', 'john@gmail.com', 'john', '$2a$10$ByG2zsX94Nks6gzpiphUJunCS3T1M6gPlS4/LiVnJyCbbhqEDpIFW', 'Driver', 'Deactivated', '2016-03-26 15:32:59'),
(9, 'Driver', 'Driver', 'Female', 'dr@gmail.com', 'driver', '$2a$10$DZ8QsHVylkAxQi.JC3tzY..ywdZsqqcRG/Mihh7K1Z3Cf3o6jC/UC', 'Manager', 'Deactivated', '2016-03-27 10:26:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`bus_id`),
  ADD UNIQUE KEY `route_id` (`route_id`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`route_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buses`
--
ALTER TABLE `buses`
  MODIFY `bus_id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `route_id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
